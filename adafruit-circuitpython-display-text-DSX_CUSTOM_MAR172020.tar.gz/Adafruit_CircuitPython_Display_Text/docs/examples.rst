Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/display_text_simpletest.py
    :caption: examples/display_text_simpletest.py
    :linenos:
