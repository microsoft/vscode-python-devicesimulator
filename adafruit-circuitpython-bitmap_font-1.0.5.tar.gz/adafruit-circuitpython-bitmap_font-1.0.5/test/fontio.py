import collections

Glyph = collections.namedtuple("Glyph", ["bitmap", "tile_index", "width", "height", "dx", "dy", "shift_x", "shift_y"])
