Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/bitmap_font_simpletest.py
    :caption: examples/bitmap_font_simpletest.py
    :linenos:
